'use strict'

module.exports = {
  qiniu: {
    creation: 'http://ojno8m75o.bkt.clouddn.com/',
    avatar: 'http://ojno8dk7j.bkt.clouddn.com/',
    AK: '你的七牛 AK',
    SK: '你的七牛 SK'
  },
  wechat: {
    base: 'https://api.weixin.qq.com/sns/jscode2session',
    appid: '你的小程序 appid',
    // appid: 'wx4f4bc4dec97d474b',
    secret: '你的小程序 secret'
  }
}
